"""NivisViewer application package."""
