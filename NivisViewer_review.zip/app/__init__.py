"""NivisViewer application package."""
