from __future__ import annotations

import os
from pathlib import Path
from threading import Event

from PySide6.QtCore import QItemSelectionModel, QPoint, QTimer, Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QLineEdit, QMessageBox

from app.browser_window import BrowserWindow
from app.config_manager import ConfigManager
from app.file_operation_coordinator import FileOperationCoordinator
from app.file_operation_service import (
    FileOperationKind,
    FileOperationResult,
    FileOperationService,
)
from app.file_operation_worker import FileOperationExecutor
from app.metadata_store import MetadataStore
from app.windows_recycle_bin import RecycleBinResult


class MovingRecycleBin:
    def __init__(self, trash: Path, *, fail: bool = False) -> None:
        self.trash = trash
        self.fail = fail
        self.paths: list[str] = []
        trash.mkdir()

    def recycle(self, path) -> RecycleBinResult:
        source = Path(path)
        self.paths.append(str(source))
        if self.fail:
            return RecycleBinResult(
                False,
                error_code="shell_error",
                error_message="failed",
            )
        source.rename(self.trash / source.name)
        return RecycleBinResult(True)


def write_file(path: Path, content: str = "data") -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def make_window(
    tmp_path: Path,
    qapp: QApplication,
    folder: Path,
    *,
    recycle_bin=None,
) -> tuple[BrowserWindow, FileOperationCoordinator]:
    config = ConfigManager(tmp_path / "config.json")
    config.load()
    config.set("last_browser_path", str(folder))
    metadata = MetadataStore(tmp_path / "metadata.sqlite3")
    service = FileOperationService(recycle_bin)
    coordinator = FileOperationCoordinator(
        metadata,
        executor=FileOperationExecutor(service),
    )
    window = BrowserWindow(
        config_manager=config,
        metadata_store=metadata,
        file_operation_coordinator=coordinator,
    )
    window.resize(700, 480)
    window.show()
    assert window.wait_for_scan()
    qapp.processEvents()
    return window, coordinator


def close_window(
    window: BrowserWindow,
    coordinator: FileOperationCoordinator,
    qapp: QApplication,
) -> None:
    window.close()
    coordinator.close()
    coordinator.metadata_store.close()
    qapp.processEvents()


def select_paths(window: BrowserWindow, paths: list[Path]) -> None:
    selection = window.list_view.selectionModel()
    selection.clearSelection()
    for position, path in enumerate(paths):
        row = window.item_model.row_for_path(path)
        assert row >= 0
        index = window.item_model.index(row, 0)
        selection.select(index, QItemSelectionModel.SelectionFlag.Select)
        if position == 0:
            window.list_view.setCurrentIndex(index)


def finish_operation(
    window: BrowserWindow,
    coordinator: FileOperationCoordinator,
    qapp: QApplication,
) -> None:
    assert coordinator.wait_for_done(3000)
    for _ in range(5):
        qapp.processEvents()
    if window._pending_scan is not None:
        assert window.wait_for_scan()
    for _ in range(5):
        qapp.processEvents()


def test_f2_rename_refreshes_and_selects_new_path_without_history_or_open(
    tmp_path: Path,
    qapp: QApplication,
    monkeypatch,
) -> None:
    folder = tmp_path / "books"
    source = folder / "old.cbz"
    write_file(source)
    window, coordinator = make_window(tmp_path, qapp, folder)
    select_paths(window, [source])
    opened = []
    window._open_path_handler = lambda *args: opened.append(args)
    monkeypatch.setattr(
        window,
        "_prompt_for_filename",
        lambda *_args: "新しい.cbz",
    )
    history_size = len(window.navigation_history)
    window.list_view.setFocus()

    QTest.keyClick(window.list_view, Qt.Key.Key_F2)
    finish_operation(window, coordinator, qapp)

    destination = folder / "新しい.cbz"
    assert destination.exists()
    assert not source.exists()
    current = window.item_model.item_at(window.list_view.currentIndex())
    assert current is not None and current.path == destination.absolute()
    assert len(window.navigation_history) == history_size
    assert opened == []
    close_window(window, coordinator, qapp)


def test_delete_uses_recycle_confirmation_and_refreshes_near_selection(
    tmp_path: Path,
    qapp: QApplication,
    monkeypatch,
) -> None:
    folder = tmp_path / "books"
    first = folder / "1.cbz"
    second = folder / "2.cbz"
    write_file(first)
    write_file(second)
    recycle = MovingRecycleBin(tmp_path / "trash")
    window, coordinator = make_window(
        tmp_path,
        qapp,
        folder,
        recycle_bin=recycle,
    )
    select_paths(window, [first])
    prompts = []

    def confirm(*args, **kwargs):
        prompts.append((args, kwargs))
        return QMessageBox.StandardButton.Yes

    monkeypatch.setattr(QMessageBox, "question", confirm)
    window.list_view.setFocus()

    QTest.keyClick(window.list_view, Qt.Key.Key_Delete)
    finish_operation(window, coordinator, qapp)

    assert len(prompts) == 1
    assert recycle.paths == [str(first.absolute())]
    assert not first.exists()
    current = window.item_model.item_at(window.list_view.currentIndex())
    assert current is not None and current.path == second.absolute()
    close_window(window, coordinator, qapp)


def test_copy_cut_paste_and_multiple_selection_use_absolute_paths(
    tmp_path: Path,
    qapp: QApplication,
    monkeypatch,
) -> None:
    source_folder = tmp_path / "source"
    destination = tmp_path / "destination"
    first = source_folder / "1.cbz"
    second = source_folder / "2.cbz"
    write_file(first, "one")
    write_file(second, "two")
    destination.mkdir()
    window, coordinator = make_window(tmp_path, qapp, source_folder)
    monkeypatch.setattr(QMessageBox, "warning", lambda *_args, **_kwargs: None)
    select_paths(window, [first, second])

    assert window.copy_selected_items()
    assert window._clipboard_paths == (
        str(first.absolute()),
        str(second.absolute()),
    )
    assert window.navigate_to(destination)
    assert window.wait_for_scan()
    assert window.paste_items()
    finish_operation(window, coordinator, qapp)

    assert (destination / "1.cbz").read_text(encoding="utf-8") == "one"
    assert (destination / "2.cbz").read_text(encoding="utf-8") == "two"
    assert {
        Path(item.path).name
        for item in window.items
    } == {"1.cbz", "2.cbz"}

    assert window.navigate_to(source_folder)
    assert window.wait_for_scan()
    select_paths(window, [first])
    assert window.cut_selected_items()
    assert window.navigate_to(destination)
    assert window.wait_for_scan()
    assert window.paste_items()
    finish_operation(window, coordinator, qapp)
    # A collision is skipped; cut state remains and neither file is overwritten.
    assert first.exists()
    assert window._clipboard_cut
    close_window(window, coordinator, qapp)


def test_specified_copy_move_and_new_folder_refresh_only_relevant_folder(
    tmp_path: Path,
    qapp: QApplication,
    monkeypatch,
) -> None:
    source_folder = tmp_path / "source"
    destination = tmp_path / "destination"
    copied = source_folder / "copy.cbz"
    moved = source_folder / "move.cbz"
    write_file(copied)
    write_file(moved)
    destination.mkdir()
    window, coordinator = make_window(tmp_path, qapp, source_folder)
    history_size = len(window.navigation_history)

    select_paths(window, [copied])
    assert window.copy_selected_to(destination)
    finish_operation(window, coordinator, qapp)
    assert (destination / copied.name).exists()
    assert copied.exists()

    select_paths(window, [moved])
    assert window.move_selected_to(destination)
    finish_operation(window, coordinator, qapp)
    assert not moved.exists()
    assert (destination / moved.name).exists()

    monkeypatch.setattr(
        window,
        "_prompt_for_filename",
        lambda *_args: "新しいフォルダ",
    )
    assert window.create_new_folder()
    finish_operation(window, coordinator, qapp)
    created = source_folder / "新しいフォルダ"
    assert created.is_dir()
    selected = window.item_model.item_at(window.list_view.currentIndex())
    assert selected is not None and selected.path == created.absolute()
    assert len(window.navigation_history) == history_size
    close_window(window, coordinator, qapp)


def test_partial_failure_is_reported_once_and_successes_are_refreshed(
    tmp_path: Path,
    qapp: QApplication,
    monkeypatch,
) -> None:
    source = tmp_path / "source"
    destination = tmp_path / "destination"
    first = source / "1.cbz"
    second = source / "2.cbz"
    write_file(first)
    write_file(second)
    destination.mkdir()
    write_file(destination / "1.cbz", "collision")
    window, coordinator = make_window(tmp_path, qapp, source)
    select_paths(window, [first, second])
    warnings = []
    monkeypatch.setattr(
        QMessageBox,
        "warning",
        lambda *args, **kwargs: warnings.append((args, kwargs)),
    )

    assert window.copy_selected_to(destination)
    finish_operation(window, coordinator, qapp)

    assert len(warnings) == 1
    assert (destination / "1.cbz").read_text(encoding="utf-8") == "collision"
    assert (destination / "2.cbz").exists()
    close_window(window, coordinator, qapp)


def test_shortcuts_do_not_steal_address_bar_text_editing(
    tmp_path: Path,
    qapp: QApplication,
) -> None:
    folder = tmp_path / "folder"
    file_path = folder / "book.cbz"
    write_file(file_path)
    recycle = MovingRecycleBin(tmp_path / "trash")
    window, coordinator = make_window(
        tmp_path,
        qapp,
        folder,
        recycle_bin=recycle,
    )
    window.address_bar.setText("abcdef")
    window.address_bar.setFocus()
    window.address_bar.setSelection(1, 2)

    QTest.keyClick(
        window.address_bar,
        Qt.Key.Key_C,
        Qt.KeyboardModifier.ControlModifier,
    )
    QTest.keyClick(window.address_bar, Qt.Key.Key_Delete)

    assert window.address_bar.text() == "adef"
    assert recycle.paths == []
    close_window(window, coordinator, qapp)


def test_blank_context_menu_contains_safe_folder_actions(
    tmp_path: Path,
    qapp: QApplication,
    monkeypatch,
) -> None:
    folder = tmp_path / "folder"
    folder.mkdir()
    window, coordinator = make_window(tmp_path, qapp, folder)
    labels = []

    class FakeAction:
        def __init__(self, text: str) -> None:
            self._text = text

        def setEnabled(self, _enabled: bool) -> None:
            pass

    class FakeMenu:
        def __init__(self, _parent=None) -> None:
            pass

        def addAction(self, text: str):
            labels.append(text)
            return FakeAction(text)

        def addSeparator(self) -> None:
            pass

        def exec(self, _position):
            return None

    monkeypatch.setattr("app.browser_window.QMenu", FakeMenu)

    window._show_context_menu(QPoint(-10, -10))

    assert "貼り付け" in labels
    assert "新しいフォルダ" in labels
    assert "更新" in labels
    assert "名前の変更" in labels
    close_window(window, coordinator, qapp)


class SlowService(FileOperationService):
    def __init__(self, started: Event, release: Event) -> None:
        self.started = started
        self.release = release

    def execute(self, request, *, cancelled=None, progress=None):
        self.started.set()
        if progress is not None:
            from app.file_operation_service import FileOperationProgress

            progress(
                FileOperationProgress(
                    request.request_id,
                    request.operation,
                    1,
                    2,
                )
            )
        self.release.wait(2)
        return FileOperationResult(
            request.operation,
            (),
            cancelled=bool(cancelled and cancelled.is_set()),
            request_id=request.request_id,
        )


def test_slow_operation_shows_progress_and_keeps_qtimer_running(
    tmp_path: Path,
    qapp: QApplication,
) -> None:
    folder = tmp_path / "folder"
    source = folder / "book.cbz"
    write_file(source)
    config = ConfigManager(tmp_path / "config.json")
    config.load()
    config.set("last_browser_path", str(folder))
    started = Event()
    release = Event()
    coordinator = FileOperationCoordinator(
        None,
        executor=FileOperationExecutor(SlowService(started, release)),
    )
    window = BrowserWindow(
        config_manager=config,
        file_operation_coordinator=coordinator,
    )
    window.show()
    assert window.wait_for_scan()
    select_paths(window, [source])
    try:
        assert window.copy_selected_to(tmp_path)
        assert started.wait(1)
        ticks = []
        QTimer.singleShot(0, lambda: ticks.append(True))
        qapp.processEvents()
        assert ticks == [True]
        assert "1 / 2" in window.statusBar().currentMessage()
        assert window.cancel_operation_button.isVisible()
    finally:
        release.set()
        coordinator.wait_for_done(2000)
        qapp.processEvents()
        window.close()
        coordinator.close()
