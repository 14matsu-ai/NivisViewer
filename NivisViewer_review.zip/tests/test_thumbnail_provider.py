from __future__ import annotations

import zipfile
from pathlib import Path
from threading import Event

from PIL import Image
from PySide6.QtGui import QImage
from PySide6.QtWidgets import QApplication

from app.browser_model import BrowserItem, BrowserItemKind
from app.thumbnail_provider import BrowserThumbnailProvider
from app.browser_thumbnail_scheduler import ThumbnailPriority
from app.thumbnail_disk_cache import ThumbnailDiskCache


def write_image(path: Path, *, color: str = "white") -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with Image.new("RGB", (24, 32), color) as image:
        image.save(path)


def make_item(path: Path, kind: BrowserItemKind) -> BrowserItem:
    return BrowserItem(path.name, path, kind, path.stat().st_mtime)


def test_loads_image_folder_and_archive_thumbnails_with_unicode_paths(
    tmp_path: Path,
) -> None:
    image = tmp_path / "日本語画像.jpg"
    write_image(image)
    folder = tmp_path / "日本語フォルダ"
    write_image(folder / "2.jpg", color="blue")
    write_image(folder / "1.jpg", color="red")
    archive = tmp_path / "日本語書庫.cbz"
    with zipfile.ZipFile(archive, "w") as output:
        output.write(folder / "2.jpg", "10.jpg")
        output.write(folder / "1.jpg", "2.jpg")

    image_thumbnail = BrowserThumbnailProvider.load_thumbnail(
        make_item(image, BrowserItemKind.IMAGE), 120
    )
    folder_thumbnail = BrowserThumbnailProvider.load_thumbnail(
        make_item(folder, BrowserItemKind.FOLDER), 120
    )
    archive_thumbnail = BrowserThumbnailProvider.load_thumbnail(
        make_item(archive, BrowserItemKind.ARCHIVE), 120
    )

    assert image_thumbnail is not None and not image_thumbnail.isNull()
    assert folder_thumbnail is not None and not folder_thumbnail.isNull()
    assert archive_thumbnail is not None and not archive_thumbnail.isNull()
    assert image_thumbnail.width() <= 120
    assert folder_thumbnail.height() <= 120
    assert folder_thumbnail.pixelColor(0, 0).red() > folder_thumbnail.pixelColor(0, 0).blue()
    assert archive_thumbnail.pixelColor(0, 0).red() > archive_thumbnail.pixelColor(0, 0).blue()


def test_corrupt_image_and_archive_fall_back_to_none(tmp_path: Path) -> None:
    image = tmp_path / "broken.jpg"
    image.write_bytes(b"not an image")
    archive = tmp_path / "broken.zip"
    archive.write_bytes(b"not a zip")

    assert (
        BrowserThumbnailProvider.load_thumbnail(
            make_item(image, BrowserItemKind.IMAGE), 100
        )
        is None
    )
    assert (
        BrowserThumbnailProvider.load_thumbnail(
            make_item(archive, BrowserItemKind.ARCHIVE), 100
        )
        is None
    )


def test_duplicate_requests_are_suppressed_and_old_generation_is_discarded(
    tmp_path: Path,
    qapp: QApplication,
) -> None:
    image_path = tmp_path / "page.jpg"
    write_image(image_path)
    item = make_item(image_path, BrowserItemKind.IMAGE)
    delivered: list[tuple[str, int]] = []

    def loader(_item: BrowserItem, _size: int) -> QImage:
        return QImage(8, 8, QImage.Format.Format_RGBA8888)

    provider = BrowserThumbnailProvider(loader=loader, max_workers=1)
    provider.thumbnail_ready.connect(
        lambda path, generation, _image: delivered.append((path, generation))
    )
    first_generation = provider.begin_generation()

    assert provider.request(item, 100, generation=first_generation)
    assert not provider.request(item, 100, generation=first_generation)
    provider.begin_generation()
    assert provider.wait_for_done(2000)
    qapp.processEvents()

    assert delivered == []
    provider.close()


def test_memory_cache_is_checked_before_decoder(
    tmp_path: Path,
    qapp: QApplication,
) -> None:
    image_path = tmp_path / "page.jpg"
    write_image(image_path)
    item = make_item(image_path, BrowserItemKind.IMAGE)
    decoder_calls: list[bool] = []

    def loader(_item: BrowserItem, _size: int) -> QImage:
        decoder_calls.append(True)
        return QImage(12, 12, QImage.Format.Format_RGBA8888)

    provider = BrowserThumbnailProvider(loader=loader)
    generation = provider.begin_generation()
    assert provider.request(item, 120, generation=generation)
    assert provider.wait_for_done(2000)
    qapp.processEvents()

    assert not provider.request(item, 120, generation=generation)
    qapp.processEvents()
    assert decoder_calls == [True]
    provider.close()


def test_disk_hit_skips_decoder_and_miss_is_persisted(
    tmp_path: Path,
    qapp: QApplication,
) -> None:
    image_path = tmp_path / "日本語.jpg"
    write_image(image_path)
    item = make_item(image_path, BrowserItemKind.IMAGE)
    cache_path = tmp_path / "cache"
    disk_cache = ThumbnailDiskCache(cache_path)
    assert disk_cache.put(
        item,
        120,
        QImage(12, 12, QImage.Format.Format_RGBA8888),
    )
    disk_cache.close()
    decoder_calls: list[bool] = []

    def loader(_item: BrowserItem, _size: int) -> QImage:
        decoder_calls.append(True)
        return QImage(8, 8, QImage.Format.Format_RGBA8888)

    provider = BrowserThumbnailProvider(
        loader=loader,
        disk_cache=ThumbnailDiskCache(cache_path, enabled=False),
        disk_cache_enabled=True,
    )
    delivered: list[QImage] = []
    provider.thumbnail_ready.connect(
        lambda _path, _generation, image: delivered.append(image)
    )
    generation = provider.begin_generation()
    assert provider.request(item, 120, generation=generation)
    assert provider.wait_for_done(2000)
    qapp.processEvents()

    assert decoder_calls == []
    assert delivered and not delivered[0].isNull()
    provider.close()

    other_size_calls: list[bool] = []

    def other_loader(_item: BrowserItem, _size: int) -> QImage:
        other_size_calls.append(True)
        return QImage(10, 10, QImage.Format.Format_RGBA8888)

    miss_provider = BrowserThumbnailProvider(
        loader=other_loader,
        disk_cache=ThumbnailDiskCache(cache_path, enabled=False),
        disk_cache_enabled=True,
    )
    generation = miss_provider.begin_generation()
    assert miss_provider.request(item, 160, generation=generation)
    assert miss_provider.wait_for_done(2000)
    qapp.processEvents()
    assert other_size_calls == [True]
    miss_provider.close()

    persisted = ThumbnailDiskCache(cache_path)
    assert persisted.get(item, 160) is not None
    persisted.close()


def test_disabled_disk_cache_is_not_accessed(
    tmp_path: Path,
    qapp: QApplication,
) -> None:
    image_path = tmp_path / "page.jpg"
    write_image(image_path)
    item = make_item(image_path, BrowserItemKind.IMAGE)

    class FakeDiskCache:
        def __init__(self) -> None:
            self.calls: list[str] = []

        def set_enabled(self, _enabled: bool) -> None:
            self.calls.append("set_enabled")

        def get(self, _item, _size):
            self.calls.append("get")
            return None

        def put(self, _item, _size, _image, **_kwargs):
            self.calls.append("put")
            return True

        def close(self) -> None:
            pass

    fake = FakeDiskCache()
    provider = BrowserThumbnailProvider(
        loader=lambda _item, _size: QImage(
            8, 8, QImage.Format.Format_RGBA8888
        ),
        disk_cache=fake,  # type: ignore[arg-type]
        disk_cache_enabled=False,
    )
    generation = provider.begin_generation()
    assert provider.request(item, 100, generation=generation)
    assert provider.wait_for_done(2000)
    qapp.processEvents()

    assert fake.calls == []
    provider.close()


def test_failed_thumbnail_is_not_retried_each_generation(
    tmp_path: Path,
    qapp: QApplication,
) -> None:
    image_path = tmp_path / "broken.jpg"
    image_path.write_bytes(b"broken")
    item = make_item(image_path, BrowserItemKind.IMAGE)
    calls: list[bool] = []

    def failing_loader(_item: BrowserItem, _size: int):
        calls.append(True)
        return None

    provider = BrowserThumbnailProvider(loader=failing_loader)
    first = provider.begin_generation()
    assert provider.request(item, 100, generation=first)
    assert provider.wait_for_done(2000)
    qapp.processEvents()
    second = provider.begin_generation()
    assert provider.request(item, 100, generation=second)
    assert provider.wait_for_done(2000)
    qapp.processEvents()

    assert calls == [True]
    provider.close()


def test_pending_prefetch_can_be_cancelled_while_visible_work_runs(
    tmp_path: Path,
) -> None:
    visible_path = tmp_path / "visible.jpg"
    prefetch_path = tmp_path / "prefetch.jpg"
    write_image(visible_path)
    write_image(prefetch_path)
    started = Event()
    release = Event()

    def loader(item: BrowserItem, _size: int) -> QImage:
        if item.path == visible_path:
            started.set()
            release.wait(2)
        return QImage(8, 8, QImage.Format.Format_RGBA8888)

    provider = BrowserThumbnailProvider(loader=loader, max_workers=1)
    generation = provider.begin_generation()
    assert provider.request(
        make_item(visible_path, BrowserItemKind.IMAGE),
        100,
        generation=generation,
        priority=ThumbnailPriority.VISIBLE,
    )
    assert started.wait(1)
    assert provider.request(
        make_item(prefetch_path, BrowserItemKind.IMAGE),
        100,
        generation=generation,
        priority=ThumbnailPriority.PREFETCH,
    )

    assert provider.cancel_prefetch_except(
        {str(visible_path)},
        size=100,
        generation=generation,
    ) == 1
    assert provider.pending_count == 1
    release.set()
    assert provider.wait_for_done(2000)
    provider.close()
